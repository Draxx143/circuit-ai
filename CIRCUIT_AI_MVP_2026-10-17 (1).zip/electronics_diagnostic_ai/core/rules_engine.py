"""Data-driven symptom-to-test routing; rules live in SQLite and JSON, not the UI."""
from __future__ import annotations

from typing import Any

from services.knowledge_service import get_test_catalog, list_rules


def match_rules(symptoms: list[str], *, path=None) -> dict[str, Any]:
    selected = set(symptoms)
    matches = []
    test_codes: list[str] = []
    for rule in list_rules(path=path):
        if not rule["enabled"]:
            continue
        triggers = set(rule.get("trigger_symptoms", []))
        if triggers & selected:
            matches.append(rule)
            for code in rule.get("action", {}).get("tests", []):
                if code not in test_codes:
                    test_codes.append(code)
    catalog = get_test_catalog(path=path)
    return {
        "rules": matches,
        "tests": [catalog[code] for code in test_codes if code in catalog],
        "unresolved_test_codes": [code for code in test_codes if code not in catalog],
    }
