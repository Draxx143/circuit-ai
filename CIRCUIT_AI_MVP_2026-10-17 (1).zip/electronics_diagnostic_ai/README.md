# CIRCUIT AI

**Intelligent Electronics Diagnostics** — دستیار محلی و آفلاین‌محور برای ثبت پرونده تعمیر و پشتیبانی عیب‌یابی بردهای کنترل صنعتی، موتور و تغذیه.

> این نسخه یک MVP اجرایی است، نه محصول تأییدشده برای تعمیرگاه و نه ابزار تشخیص قطعی. خروجی موتور «مسیر بررسی» است؛ ولتاژ/نقطه عمومی برای برد ناشناس حدس زده نمی‌شود.

## چه چیزی الان واقعاً کار می‌کند؟

- رابط Streamlit فارسی، راست‌چین و تم تیره/روشن با ۹ صفحه واقعی.
- داشبورد با شمارنده‌های مستقیم SQLite؛ هنگام خالی بودن بانک پرونده، اطلاعات نمایشی نمی‌سازد.
- ساخت و ویرایش پرونده، ثبت علائم و اندازه‌گیری با واحد/شرایط/حالت روشن یا خاموش، ثبت نتایج تست، اجرای دوباره تحلیل و بستن پرونده.
- جست‌وجو و نمایش پرونده‌های قبلی، جست‌وجوی شباهت واژه‌ای/علائم با شرح شباهت و تفاوت.
- جست‌وجوی قطعه و مشاهده اطلاعات منبع‌دار، تفکیک Operating Conditions از Absolute Maximum Ratings، ثبت قطعه جدید در وضعیت «نیازمند بررسی».
- سه ساختار مرجع مدار، سه رکورد شرایط کاری مستند، پنج قاعده عمومی محافظه‌کارانه، فهرست منابع فنی.
- محاسبات مهندسی پایه در `core/electrical_calculations.py`؛ تلرانس پیش‌فرض ساخته نمی‌شود.
- سه پروفایل داده‌محور و منبع‌دار برای شرط کاریِ `LM2596`، `TPS5430` و `DRV8825`؛ موتور حد، سیگنال‌های هم‌نام و توضیح پایه را از `data/diagnostic_rules/component_ranges.json` و DB می‌خواند (نه از mapping ثابت در کد). مقایسه فقط با مدل دقیق، واحد ولتاژ پشتیبانی‌شده و اندازه‌گیری برق‌دار انجام می‌شود.
- پشتیبان SQLite، بازیابی با بررسی سلامت و نگه‌داشتن نسخه قبل از بازیابی، خروجی JSON، بایگانی نرم پرونده.
- ابزار ممیزی manifest و ورود داده فقط با تأیید صریح انسان؛ هیچ crawl یا دانلود خودکاری در زمان اجرا انجام نمی‌شود.

**قابلیت‌های پیاده‌سازی‌نشده:** RAG، جست‌وجوی embedding، LLM، ML، OCR/استخراج قطعی دیتاشیت، کنترل چندکاربره/نقش‌ها، تشخیص waveform، اتصال سخت‌افزاری و آزمون میدانی. هیچ مدل پولی یا API لازم نیست.

## معماری

Python و SQLite هسته برنامه‌اند؛ Streamlit فقط رابط است. قوانین JSON در `data/diagnostic_rules/rules.json` جدا هستند و هنگام راه‌اندازی به جدول `diagnostic_rules` وارد می‌شوند. کاتالوگ اولیه در `data/seed_catalog.json` است؛ پرونده‌های تعمیر از seed جدا نگه داشته می‌شوند. ماژول‌های `services/` عملیات DB/پرونده/منابع/پشتیبان را انجام می‌دهند. فرمول‌ها و موتور تشخیص در `core/` مستقل از Streamlit هستند.

ساختار اصلی:

```text
electronics_diagnostic_ai/
├── app.py
├── run.sh
├── requirements.txt
├── config/settings.json
├── database/schema.sql
├── core/
│   ├── diagnostic_engine.py
│   ├── rules_engine.py
│   ├── electrical_calculations.py
│   └── confidence.py
├── services/
│   ├── db.py
│   ├── repair_service.py
│   ├── component_service.py
│   ├── knowledge_service.py
│   ├── backup_service.py
│   └── settings_service.py
├── ui/common.py
├── data/
│   ├── seed_catalog.json
│   ├── sources/component_source_links.json
│   ├── sources/manifest.example.json
│   ├── diagnostic_rules/rules.json
│   ├── diagnostic_rules/component_ranges.json
│   └── catalog.sqlite3       # فقط بانک بذر اولیه، بدون پرونده تعمیر کاربر
├── tools/{manage_data.py,source_intake.py}
├── tests/
└── docs/{ARCHITECTURE.md,SAFETY.md,DATA_ACQUISITION_REPORT.md,ROADMAP.md}
```

برای تغییر نام یا زیرعنوان، `config/settings.json` را ویرایش کنید. تنظیم تم کاربر در SQLite می‌ماند.

## نصب و اجرای Ubuntu 24.04

نیازمندی: Python 3.10+، دسترسی به ترمینال و مرورگر. Ubuntu 24.04 معمولاً Python 3.12 دارد.

```bash
cd electronics_diagnostic_ai
python3 --version
```

اگر `python3` یا ماژول `venv` در نصب Ubuntu شما وجود ندارد، فقط همان بسته مفقود را نصب کنید؛ `sudo` برای اجرای برنامه لازم نیست:

```bash
sudo apt install python3 python3-venv python3-pip
```

محیط مجازی را بسازید و وابستگی‌ها را نصب کنید:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

راه‌اندازی DB، seed کاتالوگ، تست‌ها و اجرای برنامه:

```bash
python tools/manage_data.py init
python -m pytest -q
./run.sh
```

مرورگر را روی `http://127.0.0.1:8501` باز کنید. اجرای `./run.sh` به‌تنهایی دانلود بسته انجام نمی‌دهد؛ اگر وابستگی‌ها نصب نیستند، راهنمای روشن می‌دهد. نصب اختیاری با یک دستور:

```bash
./run.sh --install
```

این گزینه به اینترنت/PyPI نیاز دارد. برای نصب کاملاً آفلاین، wheelهای موردنیاز را از منبع مورد اعتماد آماده کنید و از pip محلی استفاده کنید:

```bash
python -m pip install --no-index --find-links /path/to/wheelhouse -r requirements.txt
```

### اجرا پس از بستن ترمینال

```bash
mkdir -p "$HOME/.local/state/circuit-ai"
nohup ./run.sh >"$HOME/.local/state/circuit-ai/streamlit.log" 2>&1 &
echo $! > "$HOME/.local/state/circuit-ai/streamlit.pid"
```

برای توقف، PID ثبت‌شده را با `kill` متوقف کنید؛ این کار پرونده‌ها را حذف نمی‌کند. گزارش اجرا در `~/.local/state/circuit-ai/streamlit.log` است.

برنامه به‌صورت پیش‌فرض فقط روی loopback (`127.0.0.1`) گوش می‌دهد. تنظیم `CIRCUIT_AI_HOST=0.0.0.0` برنامه را به شبکه‌های دیگر هم در دسترس می‌کند؛ فقط در شبکه مورد اعتماد و با آگاهی از دسترسی‌ها استفاده شود.

## محل داده و تنظیم مسیر

- مسیر پیش‌فرض: `~/.local/share/circuit-ai/circuit_ai.sqlite3`
- اگر `XDG_DATA_HOME` تنظیم شده باشد: `$XDG_DATA_HOME/circuit-ai/circuit_ai.sqlite3`
- مسیر دستی: `CIRCUIT_AI_DB_PATH=/path/to/circuit_ai.sqlite3`

این مسیر از فایل‌های برنامه جداست و پاک‌کردن/به‌روزرسانی پوشه پروژه نباید پرونده‌های کاربر را حذف کند. `data/catalog.sqlite3` یک کاتالوگ seed برای ممیزی پروژه است؛ مسیر پیش‌فرض برنامه آن نیست. تمام پرونده‌های این نسخه روی همان رایانه ذخیره می‌شوند؛ رمزنگاری سمت برنامه یا کنترل دسترسی چندکاربره نداریم، پس مجوز فایل و رمزگذاری دیسک/بکاپ را رعایت کنید.

## پشتیبان‌گیری، بازیابی و خروجی

از صفحه «مدیریت پایگاه داده» یا CLI استفاده کنید:

```bash
python tools/manage_data.py report
python tools/manage_data.py backup "$HOME/Documents/circuit-ai-backup.sqlite3"
python tools/manage_data.py export "$HOME/Documents/circuit-ai-export.json"
python tools/manage_data.py restore "$HOME/Documents/circuit-ai-backup.sqlite3"
```

- فایل مقصد موجود بازنویسی نمی‌شود.
- قبل از restore، SQLite سلامت و جداول لازم را بررسی می‌کند؛ فایل پایگاه فعلی با پسوند `.before-restore-<timestamp>.bak` نگه داشته می‌شود.
- خروجی JSON و فایل پشتیبان ممکن است شامل اطلاعات حساس تعمیر باشد؛ آن‌ها را با دیگران به اشتراک نگذارید.
- برای اطمینان، دوره‌ای restore را روی یک مسیر آزمایشی جداگانه تمرین کنید.

## بروزرسانی بدون حذف اطلاعات

پیش از تغییر نسخه یک بکاپ بیرون از پوشه پروژه بگیرید:

```bash
python tools/manage_data.py backup "$HOME/Documents/circuit-ai-before-update.sqlite3"
# در نسخه Git: git pull
source .venv/bin/activate
python -m pip install -r requirements.txt
python tools/manage_data.py init
python -m pytest -q
```

`init` schema را به‌صورت افزایشی به‌روز می‌کند و پرونده‌های موجود را reset نمی‌کند. از دستورهای `rm -rf` برای پاک‌کردن پوشه داده کاربر استفاده نکنید. حذف برنامه نیز با پاک‌کردن پوشه پروژه، داده XDG را خودکار حذف نمی‌کند.

## داده اولیه و اعتبار فنی

Seed فعلی شامل **۵ قطعه با ۵ دیتاشیت رسمی بررسی‌شده (۱۰۰٪)**، یک صفحه محصول رسمی اضافی، ۳ ساختار مدار، ۳ پروفایل شرط کاری داده‌محور و منبع‌دار، ۳ شرط کاری مستند و ۵ قاعده عمومی است. **هیچ قطعه آزمایشگاه/روی برد تأیید نشده و هیچ پرونده تعمیر نمونه/جعلی درج نشده است.** دو رکورد (1N4148 و IRLZ44N) عمداً فیلد محدوده کاری/پایه کامل ندارند؛ مقدار ناشناخته خالی مانده است. پنج قانون عمومی همگی نیازمند بازبینی انسانی‌اند. جزئیات منبع، سندهای بازنشده، تعدادها و محدودیت‌ها در [گزارش گردآوری داده](docs/DATA_ACQUISITION_REPORT.md) آمده است.

برای افزودن manifest:

```bash
python tools/source_intake.py data/sources/manifest.example.json \
  --out data/reports/intake-report.json
```

ابزار جست‌وجوی وب پنهان ندارد. دانلود فقط با `--download` انجام می‌شود و فقط URLهای HTTPS ناشران allowlist شده را می‌پذیرد. متن PDF اختیاری است (`pypdf`) و هیچ‌وقت به‌تنهایی به معنی تأیید داده نیست. واردکردن به DB فقط با `--import-approved`، نام بازبین، بخش‌های سند و یادداشت بررسی انسانی ممکن است.

## موتور تشخیص و حدود نتیجه

- هیچ `confidence_percent` برای خرابی تولید نمی‌شود. موتور فقط «کیفیت شواهد» و ترتیب بررسی توضیح‌پذیر می‌دهد.
- مقایسه مقدار اندازه‌گیری با مرجع فقط وقتی انجام می‌شود که کاربر مرجع و در صورت نیاز تلرانس/شرایط منبع را ثبت کند.
- پروفایل‌های داده‌ای بازهٔ کاری فعلاً برای سه مدل بالا هستند؛ گسترش آن‌ها باید با منبع/نسخه مشخص، حدِ Recommended Operating Conditions، نقطه/نام سیگنال و تست انجام شود. حتی در آن موارد هم نتیجه فقط «شرط کاری بیرون از بازه توصیه‌شده» است، نه خرابی IC.
- جست‌وجوی مشابه بر پایه واژه و علائم است، نه شباهت آماری/یادگیری ماشین؛ وضعیت `unverified` کنار پرونده دیده می‌شود.
- برای راهنمای ایمنی کامل‌تر: [docs/SAFETY.md](docs/SAFETY.md).

## آزمون‌ها و وضعیت پلتفرم

آخرین اجرای محلی در محیط ساخت:

- Linux x86_64، Debian 13، Python 3.13.16 (محیط اجرای این sandbox؛ **Ubuntu 24.04 را مستقیماً در این محیط اجرا نکرده‌ایم**).
- Streamlit 1.66.0، Pandas 3.0.6؛ همه وابستگی‌ها در `.venv` نصب شدند.
- `pytest`: **40 passed**؛ شامل فرمول‌ها، DB/مهاجرت schema v3، seed/provenance پروفایل، استفاده موتور از پروفایل داده‌ای، امتناع از نتیجه‌گیری با بازه ناقص، persistence پرونده، validation، قواعد، ranking توضیح‌پذیر، مشابه‌یابی، intake و backup/restore.
- Streamlit `AppTest`: هر ۹ صفحه بدون exception. جریان UI از ساخت پرونده تا ثبت علائم، ثبت VIN=4.9 V با مدل مشخص TPS5430 و نمایش هشدارِ «شرط خارج از بازه، نه تشخیص خرابی» نیز بدون exception اجرا شد.
- HTTP health check محلی: `ok`.

اجرای موفق روی Ubuntu 24.04 هدف طراحی است؛ تست نهایی روی آن سیستم/دستگاه تعمیرگاه هنوز لازم است. این گزارش ادعای صحت میدانی یا دقت تشخیصی نیست.

## فاز بعدی

طبق [نقشه راه](docs/ROADMAP.md)، گام بعدی: فرایند مستقل بازبینی/تأیید پرونده و افزودن منبع محلی با هش/صفحه/نسخه، سپس توسعه قواعد فقط با تست و بازبینی متخصص. داده واقعی و تاییدشده باید قبل از بررسی ML/RAG جمع‌آوری شود.
